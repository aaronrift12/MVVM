package com.example.mvvm.constant;

public class AppConstant {
    public static final String BASE_URL="https://newsapi.org/v2/";

    public static final String API_KEY="2fc92c680fc84d42afa3af335d301e82";
}
