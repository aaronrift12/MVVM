package com.example.mvvm.view_model;

public class ArticleViewModel {
}
